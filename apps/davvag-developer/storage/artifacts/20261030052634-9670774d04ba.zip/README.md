# DAVVAG deployment package

Review and install through DAVVAG Developer. This package is unsigned and requires explicit trust approval.
