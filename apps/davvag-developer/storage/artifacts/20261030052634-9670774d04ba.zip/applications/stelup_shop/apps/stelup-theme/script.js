WEBDOCK.component().register(function () {});
