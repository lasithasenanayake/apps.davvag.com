ALTER TABLE davvag_summery 
ADD FULLTEXT INDEX davvag_summery_id3 (description ASC, title ASC, tag ASC);